# Как выполнить весь отчет целиком

## ⚠️ Проблема

Вы видите только один результат, потому что выполнен только **последний запрос** из скрипта.

Скрипт `cleanup_orphaned_data_report.sql` содержит **более 14 проверок**, и нужно выполнить **весь скрипт целиком**.

## ✅ Правильный способ выполнения

### В DBeaver:

1. **Откройте SQL Editor** (если еще не открыт)
   - Нажмите **Ctrl+`** или **Ctrl+Enter**

2. **Откройте файл** `cleanup_orphaned_data_report.sql`
   - Нажмите **Ctrl+O**
   - Выберите файл
   - Нажмите **"Open"**

3. **Выделите весь текст скрипта:**
   - Нажмите **Ctrl+A** (выделить все)

4. **Выполните весь скрипт:**
   - Нажмите **F5** (Execute SQL Script)
   - Или нажмите кнопку **"Execute SQL Script"** на панели инструментов

5. **Просмотрите все результаты:**
   - В нижней панели должны появиться **множество строк** с результатами
   - Прокрутите вниз, чтобы увидеть все категории

## 📊 Что вы должны увидеть

После выполнения всего скрипта вы увидите таблицу примерно такого вида:

```
| issue_type                                    | orphaned_count |
| --------------------------------------------- | -------------- |
| attendance (orphaned enrollments)             | 0              |
| attendance (orphaned group_lessons)          | 0              |
| enrollments (orphaned students)              | 0              |
| enrollments (orphaned activities)            | 0              |
| finance_transactions (orphaned students)      | 0              |
| finance_transactions (orphaned activities)   | 0              |
| finance_transactions (orphaned staff)        | 0              |
| staff_journal_entries (orphaned staff)       | 0              |
| staff_journal_entries (orphaned activities)  | 0              |
| staff_journal_entries (orphaned group_lessons)| 0              |
| staff_billing_rules (orphaned staff)         | 0              |
| staff_billing_rules (orphaned activities)    | 0              |
| staff_billing_rules (orphaned group_lessons) | 0              |
| group_lesson_sessions (orphaned group_lessons)| 0              |
| group_lessons (orphaned activities)          | 0              |
| group_lesson_staff (orphaned group_lessons)  | 0              |
| group_lesson_staff (orphaned staff)          | 0              |
| activity_teacher_history (orphaned activities)| 0              |
| activity_teacher_history (orphaned staff)    | 0              |
| activity_price_history (orphaned activities) | 0              |
| staff_payouts (orphaned staff)               | 0              |
| enrollments (orphaned teacher_id)            | 0              |
```

## 🎯 Если все результаты = 0

Если **все строки** показывают `orphaned_count = 0`, это означает:
- ✅ В базе данных **нет "мусорных" записей**
- ✅ Все связи между таблицами **корректны**
- ✅ Очистка **не требуется**

## ⚠️ Если есть ненулевые значения

Если какая-то строка показывает число больше 0, например:
```
| attendance (orphaned enrollments) | 15 |
```

Это означает, что есть 15 записей посещаемости с несуществующими записями, и их нужно удалить.

В этом случае:
1. Запишите количество "мусорных" записей
2. Выполните скрипт очистки `cleanup_orphaned_data.sql`

## 🔧 Альтернативный способ

Если не получается выполнить весь скрипт сразу:

1. Скопируйте **весь текст** из файла `cleanup_orphaned_data_report.sql`
2. Вставьте в SQL Editor (Ctrl+V)
3. Выделите все (Ctrl+A)
4. Выполните (F5)

## 💡 Важно

- Выполняйте **весь скрипт целиком**, а не отдельные запросы
- Просматривайте **все результаты**, а не только последний
- Если все нули - очистка не нужна
- Если есть ненулевые значения - выполните очистку
