# Полное руководство по подключению к Supabase PostgreSQL

## ❌ Ошибка: "FATAL: Tenant or user not found"

Эта ошибка возникает, когда username указан неправильно или используется неправильный формат подключения.

## ✅ Правильные настройки подключения

### Вариант 1: Через Connection Pooling (рекомендуется)

**Настройки:**
- **Host:** `aws-0-eu-west-1.pooler.supabase.com`
- **Port:** `6543` (важно! Это порт для pooling)
- **Database:** `postgres`
- **Username:** `postgres.qtphickigswerhvintvh` (с префиксом `postgres.`)
- **Password:** ваш пароль базы данных

**Connection String:**
```
postgresql://postgres.qtphickigswerhvintvh:ВАШ_ПАРОЛЬ@aws-0-eu-west-1.pooler.supabase.com:6543/postgres
```

### Вариант 2: Прямое подключение (без pooling)

**Настройки:**
- **Host:** `db.qtphickigswerhvintvh.supabase.co`
- **Port:** `5432`
- **Database:** `postgres`
- **Username:** `postgres` (просто `postgres`, БЕЗ префикса!)
- **Password:** ваш пароль базы данных

**Connection String:**
```
postgresql://postgres:ВАШ_ПАРОЛЬ@db.qtphickigswerhvintvh.supabase.co:5432/postgres
```

## 🔍 Где взять правильные настройки

1. Откройте: https://app.supabase.com/project/qtphickigswerhvintvh/settings/database
2. Найдите раздел **"Connection string"**
3. Выберите вкладку **"Connection pooling"** или **"Direct connection"**
4. Скопируйте connection string оттуда

## ⚠️ Важные моменты

### Для Connection Pooling (порт 6543):
- ✅ Host: `aws-0-eu-west-1.pooler.supabase.com`
- ✅ Port: `6543`
- ✅ Username: `postgres.qtphickigswerhvintvh` (С префиксом!)
- ✅ Рекомендуется для большинства случаев

### Для Direct Connection (порт 5432):
- ✅ Host: `db.qtphickigswerhvintvh.supabase.co`
- ✅ Port: `5432`
- ✅ Username: `postgres` (БЕЗ префикса!)
- ⚠️ Может иметь ограничения на бесплатном плане

## 🔧 Настройки в DBeaver

### Шаг 1: Создайте новое подключение
1. Правый клик на "Databases" → "New" → "Database Connection"
2. Выберите "PostgreSQL"

### Шаг 2: Основные настройки (Connection Pooling)
- **Host:** `aws-0-eu-west-1.pooler.supabase.com`
- **Port:** `6543`
- **Database:** `postgres`
- **Username:** `postgres.qtphickigswerhvintvh`
- **Password:** ваш пароль

### Шаг 3: Дополнительные настройки
Перейдите на вкладку **"SSL"** или **"Advanced"**:
- **SSL Mode:** `require` или `prefer`
- Или оставьте по умолчанию

### Шаг 4: Тест подключения
1. Нажмите **"Test Connection"**
2. Если ошибка - попробуйте Вариант 2 (Direct Connection)

## 🔄 Альтернатива: Direct Connection

Если Connection Pooling не работает, попробуйте прямое подключение:

**Настройки:**
- **Host:** `db.qtphickigswerhvintvh.supabase.co`
- **Port:** `5432`
- **Database:** `postgres`
- **Username:** `postgres` (БЕЗ префикса проекта!)
- **Password:** ваш пароль

## 📋 Проверка пароля

Если все еще не работает:

1. Убедитесь, что пароль правильный:
   - Откройте: https://app.supabase.com/project/qtphickigswerhvintvh/settings/database
   - Найдите раздел "Database password"
   - Если забыли - нажмите "Reset database password"
   - **ВАЖНО:** Новый пароль показывается только один раз!

2. Проверьте, что пароль скопирован полностью (без пробелов в начале/конце)

## 🎯 Рекомендуемый порядок действий

1. **Попробуйте Connection Pooling** (порт 6543, username с префиксом)
2. **Если не работает** - попробуйте Direct Connection (порт 5432, username без префикса)
3. **Проверьте пароль** - возможно, нужно сбросить
4. **Проверьте SSL настройки** - может потребоваться включить/выключить

## 🔗 Полезные ссылки

- Настройки БД: https://app.supabase.com/project/qtphickigswerhvintvh/settings/database
- Документация Supabase: https://supabase.com/docs/guides/database/connecting-to-postgres
