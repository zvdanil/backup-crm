# Создание бэкапа на бесплатном плане Supabase

## ⚠️ Важно

На **бесплатном плане Supabase** нет автоматических бэкапов через Dashboard. Нужно создавать бэкапы вручную.

## 🚀 Быстрый способ (рекомендуется)

### Шаг 1: Получите пароль базы данных

1. Откройте: https://app.supabase.com/project/qtphickigswerhvintvh/settings/database
2. Найдите раздел **"Connection string"** или **"Database password"**
3. Если пароль забыт, нажмите **"Reset database password"**
4. Скопируйте пароль

### Шаг 2: Запустите скрипт

```powershell
.\create_backup_interactive.ps1
```

Скрипт:
- ✅ Запросит пароль безопасно (не будет виден на экране)
- ✅ Попытается создать бэкап через Supabase CLI
- ✅ Если не получится, попробует через pg_dump
- ✅ Сохранит бэкап в файл `backup_YYYYMMDD_HHMMSS.sql`

## 📋 Альтернативные способы

### Способ 1: Через Supabase CLI (требует Docker)

```powershell
# Установите Docker Desktop, затем:
npx supabase db dump --db-url "postgresql://postgres.qtphickigswerhvintvh:ВАШ_ПАРОЛЬ@aws-0-eu-west-1.pooler.supabase.com:6543/postgres" --file backup.sql
```

### Способ 2: Через pg_dump (требует PostgreSQL)

```powershell
$env:PGPASSWORD = "ВАШ_ПАРОЛЬ"
pg_dump -h aws-0-eu-west-1.pooler.supabase.com -p 6543 -U postgres.qtphickigswerhvintvh -d postgres -f backup.sql --no-owner --no-acl
```

### Способ 3: Через онлайн инструменты

Используйте инструменты типа:
- DBeaver
- pgAdmin
- TablePlus

Подключитесь к базе и экспортируйте данные.

## 🔄 Рекомендации для регулярных бэкапов

1. **Создавайте бэкапы регулярно** (минимум раз в день)
2. **Автоматизируйте процесс:**
   - Создайте задачу в Windows Task Scheduler
   - Используйте GitHub Actions для автоматических бэкапов
   - Настройте cron job на сервере (если есть)

3. **Храните бэкапы в безопасном месте:**
   - Локально (но не только!)
   - В облаке (Google Drive, Dropbox, etc.)
   - В Git (только структура, без данных!)

## 📝 Пример автоматизации через PowerShell

Создайте файл `backup_scheduled.ps1`:

```powershell
# Запускайте через Task Scheduler ежедневно
$password = "ВАШ_ПАРОЛЬ"  # Или используйте переменную окружения
$timestamp = Get-Date -Format 'yyyyMMdd'
$backupFile = "backups\backup_$timestamp.sql"

# Создайте папку для бэкапов
New-Item -ItemType Directory -Force -Path "backups"

# Создайте бэкап
$dbUrl = "postgresql://postgres.qtphickigswerhvintvh:$password@aws-0-eu-west-1.pooler.supabase.com:6543/postgres"
npx supabase db dump --db-url $dbUrl --file $backupFile

# Удалите старые бэкапы (старше 30 дней)
Get-ChildItem "backups\backup_*.sql" | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } | Remove-Item
```

## ⚡ Сейчас: Быстрое создание бэкапа

**Запустите прямо сейчас:**

```powershell
.\create_backup_interactive.ps1
```

Скрипт запросит пароль и создаст бэкап автоматически!
