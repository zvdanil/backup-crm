# Исправление настроек подключения к базе данных Supabase

## ❌ Проблема

В настройках подключения указан неправильный **Username**.

**Текущее значение (неправильно):**
```
Username: qtphickigswerhvintvh
```

**Правильное значение:**
```
Username: postgres.qtphickigswerhvintvh
```

## ✅ Правильные настройки подключения

### Для DBeaver или других инструментов:

**Основные параметры:**
- **Host:** `aws-0-eu-west-1.pooler.supabase.com`
- **Port:** `6543`
- **Database:** `postgres`
- **Username:** `postgres.qtphickigswerhvintvh` ⚠️ **ВАЖНО: с префиксом `postgres.`**
- **Password:** ваш пароль базы данных

### Дополнительные настройки (если нужно):

**SSL настройки:**
- **SSL Mode:** `require` или `prefer`
- Или включите SSL в разделе "Advanced" или "SSL"

**Connection Pooling:**
- Используйте порт `6543` для connection pooling (рекомендуется)
- Или порт `5432` для прямого подключения

## 🔧 Как исправить в DBeaver:

1. Откройте настройки подключения
2. В поле **"Ім'я користувача:" (Username:)** измените:
   - ❌ Было: `qtphickigswerhvintvh`
   - ✅ Должно быть: `postgres.qtphickigswerhvintvh`
3. Проверьте, что пароль правильный
4. Нажмите **"Перевірити підключення" (Test connection)**
5. Если все правильно, нажмите **"OK"**

## 📋 Полный Connection String:

Если используете connection string напрямую:

```
postgresql://postgres.qtphickigswerhvintvh:ВАШ_ПАРОЛЬ@aws-0-eu-west-1.pooler.supabase.com:6543/postgres
```

**Формат:**
```
postgresql://postgres.[PROJECT_REF]:[PASSWORD]@aws-0-eu-west-1.pooler.supabase.com:6543/postgres
```

## 🔍 Где взять правильные настройки:

1. Откройте: https://app.supabase.com/project/qtphickigswerhvintvh/settings/database
2. Найдите раздел **"Connection string"**
3. Скопируйте connection string - там будет правильный username с префиксом `postgres.`

## ⚠️ Частые ошибки:

1. **Неправильный username** - должен быть `postgres.qtphickigswerhvintvh`, а не просто `qtphickigswerhvintvh`
2. **Неправильный порт** - используйте `6543` для pooling или `5432` для прямого подключения
3. **Неправильный пароль** - проверьте пароль в Supabase Dashboard
4. **SSL не включен** - может потребоваться включить SSL в настройках

## ✅ Проверка подключения:

После исправления username попробуйте:
1. Нажать **"Перевірити підключення" (Test connection)**
2. Если подключение успешно - вы увидите сообщение об успехе
3. Если ошибка - проверьте пароль и SSL настройки
