# Очистка неактивных записей (enrollments)

## 📊 Ситуация

Вы видите неактивные записи (`is_active = false`), которые все еще отображаются в интерфейсе, потому что у них есть записи посещаемости.

**Пример:**
- Запись: `9e0b7df7-a66e-40bd-9eb7-93de0998f0b4`
- Студент: Абубакірова Асія
- Активность: Хореография
- Статус: `is_active = false`
- Записей посещаемости: 11

## 🤔 Что делать?

### Вариант 1: Удалить неактивные записи БЕЗ посещаемости (безопасно)

Эти записи можно удалить безопасно, так как у них нет истории посещаемости:

```sql
-- Показать записи, которые будут удалены
SELECT 
    e.id,
    s.full_name as student_name,
    act.name as activity_name,
    e.unenrolled_at
FROM public.enrollments e
LEFT JOIN public.students s ON s.id = e.student_id
LEFT JOIN public.activities act ON act.id = e.activity_id
WHERE e.is_active = false
  AND e.id NOT IN (
    SELECT DISTINCT enrollment_id 
    FROM public.attendance 
    WHERE enrollment_id IS NOT NULL
  );

-- Удалить их
DELETE FROM public.enrollments
WHERE is_active = false
  AND id NOT IN (
    SELECT DISTINCT enrollment_id 
    FROM public.attendance 
    WHERE enrollment_id IS NOT NULL
  );
```

### Вариант 2: Удалить записи посещаемости для неактивных записей

Если история посещаемости не нужна:

```sql
-- Показать записи посещаемости, которые будут удалены
SELECT 
    a.id,
    a.date,
    a.status,
    a.charged_amount,
    s.full_name as student_name,
    act.name as activity_name
FROM public.attendance a
INNER JOIN public.enrollments e ON e.id = a.enrollment_id
LEFT JOIN public.students s ON s.id = e.student_id
LEFT JOIN public.activities act ON act.id = e.activity_id
WHERE e.is_active = false;

-- Удалить записи посещаемости для неактивных записей
DELETE FROM public.attendance
WHERE enrollment_id IN (
    SELECT id FROM public.enrollments WHERE is_active = false
);

-- Затем удалить неактивные записи
DELETE FROM public.enrollments
WHERE is_active = false;
```

### Вариант 3: Изменить логику отображения в коде (рекомендуется)

Вместо удаления данных, можно изменить код, чтобы не показывать неактивные записи:

**В `AttendanceGrid.tsx`:**
```typescript
// Было:
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => 
    enrollment.is_active || enrollmentsWithCharges.has(enrollment.id)
  )
), [enrollments, enrollmentsWithCharges]);

// Станет (показывать только активные):
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => enrollment.is_active)
), [enrollments]);
```

**В `GardenAttendanceJournal.tsx`** (строка 119):
```typescript
// Аналогично изменить
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => enrollment.is_active)
), [enrollments]);
```

**В `EnhancedDashboard.tsx`** (строки 118-124):
```typescript
// Изменить функцию shouldShowEnrollment
const shouldShowEnrollment = useMemo(
  () => (enrollment: { id: string; is_active: boolean; student_id: string; activity_id: string }) =>
    enrollment.is_active, // Только активные
  []
);
```

---

## 📋 Рекомендуемый порядок действий

### Шаг 1: Проверьте все неактивные записи

Выполните запрос из файла `check_inactive_enrollments.sql` в DBeaver:
1. Откройте SQL Editor (Ctrl+`)
2. Откройте файл `check_inactive_enrollments.sql` (Ctrl+O)
3. Выполните первый запрос (F5)
4. Просмотрите все неактивные записи с посещаемостью

### Шаг 2: Решите, что делать

**Если история посещаемости НЕ нужна:**
- Используйте Вариант 2 (удалить посещаемость и записи)

**Если история посещаемости НУЖНА:**
- Используйте Вариант 3 (изменить логику отображения)

**Если хотите оставить только записи с историей:**
- Используйте Вариант 1 (удалить только записи без посещаемости)

### Шаг 3: Выполните выбранное решение

---

## ⚠️ Важно

- **Сделайте бэкап** перед удалением данных (уже есть: `dump-postgres-202601230001`)
- **Проверьте результаты** после удаления
- **Если что-то пошло не так** - восстановите из бэкапа

---

## 🎯 Что делать сейчас?

1. **Выполните запрос** из `check_inactive_enrollments.sql`
2. **Просмотрите все результаты** - сколько неактивных записей
3. **Решите, что делать:**
   - Удалить данные (Вариант 1 или 2)
   - Или изменить логику отображения (Вариант 3)
4. **Сообщите, какой вариант выбираете** - я помогу реализовать
