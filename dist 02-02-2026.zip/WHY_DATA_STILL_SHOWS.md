# Почему данные все еще отображаются, если "мусорных" данных нет?

## ✅ Результаты проверки

Все проверки показывают **0 "мусорных" записей** - это означает, что:
- Все связи между таблицами корректны
- Нет записей с несуществующими ссылками
- База данных в отличном состоянии

## 🤔 Но данные все еще отображаются?

Если вы видите данные, которые не должны отображаться, причина скорее всего в **логике отображения в коде**, а не в "мусорных" данных.

### Проблема в коде приложения

Я нашел в коде логику, которая показывает **неактивные записи**, если у них есть записи посещаемости:

**В `AttendanceGrid.tsx` (строка 59):**
```typescript
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => 
    enrollment.is_active || enrollmentsWithCharges.has(enrollment.id)
  )
), [enrollments, enrollmentsWithCharges]);
```

**Это означает:**
- Показываются **активные** записи (`is_active = true`)
- И **неактивные** записи, у которых есть записи посещаемости (`enrollmentsWithCharges`)

### Почему это происходит?

Код специально показывает неактивные записи, если:
- У них есть записи посещаемости с начислением (`charged_amount > 0`)
- Это нужно для отображения исторических данных

---

## 🔍 Дополнительные проверки

Выполните эти запросы, чтобы понять, что именно отображается:

### 1. Проверка неактивных записей:

```sql
-- Неактивные записи (enrollments)
SELECT 
    e.id,
    e.student_id,
    e.activity_id,
    e.is_active,
    e.unenrolled_at,
    s.full_name as student_name,
    a.name as activity_name
FROM public.enrollments e
LEFT JOIN public.students s ON s.id = e.student_id
LEFT JOIN public.activities a ON a.id = e.activity_id
WHERE e.is_active = false
ORDER BY e.unenrolled_at DESC;
```

### 2. Проверка записей с посещаемостью:

```sql
-- Записи с посещаемостью, но неактивные
SELECT 
    e.id,
    e.is_active,
    COUNT(a.id) as attendance_count,
    s.full_name as student_name,
    act.name as activity_name
FROM public.enrollments e
LEFT JOIN public.students s ON s.id = e.student_id
LEFT JOIN public.activities act ON act.id = e.activity_id
LEFT JOIN public.attendance a ON a.enrollment_id = e.id
WHERE e.is_active = false
GROUP BY e.id, e.is_active, s.full_name, act.name
HAVING COUNT(a.id) > 0
ORDER BY attendance_count DESC;
```

### 3. Проверка неактивных студентов:

```sql
-- Неактивные студенты
SELECT 
    id,
    full_name,
    status,
    created_at
FROM public.students
WHERE status != 'active' OR status IS NULL;
```

### 4. Проверка неактивных активностей:

```sql
-- Неактивные активности
SELECT 
    id,
    name,
    is_active,
    created_at
FROM public.activities
WHERE is_active = false;
```

---

## 💡 Решения

### Вариант 1: Изменить логику отображения в коде

Если вы хотите скрыть неактивные записи полностью:

**В `AttendanceGrid.tsx`:**
```typescript
// Было:
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => 
    enrollment.is_active || enrollmentsWithCharges.has(enrollment.id)
  )
), [enrollments, enrollmentsWithCharges]);

// Станет (показывать только активные):
const visibleEnrollments = useMemo(() => (
  enrollments.filter(enrollment => enrollment.is_active)
), [enrollments]);
```

### Вариант 2: Удалить неактивные записи с посещаемостью

Если неактивные записи больше не нужны:

```sql
-- Удалить неактивные записи, у которых нет посещаемости
DELETE FROM public.enrollments
WHERE is_active = false
  AND id NOT IN (
    SELECT DISTINCT enrollment_id 
    FROM public.attendance 
    WHERE enrollment_id IS NOT NULL
  );
```

### Вариант 3: Пометить как удаленные

Вместо удаления, можно пометить:

```sql
-- Обновить статус неактивных записей
UPDATE public.enrollments
SET is_active = false, unenrolled_at = CURRENT_TIMESTAMP
WHERE is_active = true 
  AND student_id IN (
    SELECT id FROM public.students WHERE status != 'active'
  );
```

---

## 🎯 Рекомендации

1. **Сначала выполните дополнительные проверки** - чтобы понять, что именно отображается
2. **Решите, что делать:**
   - Если это неактивные записи с историей - возможно, их нужно оставить, но скрыть в интерфейсе
   - Если это старые данные - можно удалить или пометить как архивные
3. **Измените логику отображения** или **удалите данные** в зависимости от ваших потребностей

---

## 📋 Что делать сейчас?

1. **Выполните дополнительные запросы** выше, чтобы понять, что отображается
2. **Пришлите результаты** - я помогу решить, что с ними делать
3. **Или опишите, какие именно данные** вы видите в интерфейсе, которые не должны там быть
